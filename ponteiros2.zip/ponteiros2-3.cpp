#include <iostream>
using namespace std;

void vetor10X10()
{
    struct ponto
    {
        int x;
        int y;
    };
    typedef struct ponto;

    ponto vetor[10];
    for (int i = 0; i < 10; i++)
    {
        *(vetor + i) = {rand(), rand()};
        cout << *(vetor + i).x << endl;
        cout << *(vetor + i).y << endl;
    }
}

int main()
{
    vetor10X10();
}